// Begin

// NOTE: If you use a ' add a slash before it like this \'


document.write('<span class="subtitle">');

document.write('Edit With Your Company Name');

document.write('</span><br>');

document.write('10901 Yourstreet Avenue<br>');

document.write('Chicago, IL 60060<br>');

document.write('<span class="subtitle">(847) 555-5555</span> (Phone)<br>');

document.write('<span class="subtitle">(847) 555-5555</span> (Fax)<br>');

document.write('<br><br>');

document.write('Email Us:<br>');

document.write('<a href="mailto:info@your-web-domain.com" class="email sidelink">info@your-web-domain.com</a><br>');
