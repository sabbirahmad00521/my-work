jQuery(document).ready(function ($) {

   //   Responsive manu
   jQuery("nav .responsive-menu").click(function () {
      jQuery("nav ul").slideToggle();

      return false;
   });

});
