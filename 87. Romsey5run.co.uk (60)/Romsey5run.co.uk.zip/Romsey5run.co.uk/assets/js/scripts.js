jQuery(document).ready(function ($) {

    // Owl Carousel

    $('.hero-area').owlCarousel({
        items: 1,
        loop: true,
        autoplay: true,
        autoplayTimeout: 4000,
        animateOut: 'fadeOut',
    });


    // Other Scripts


});
