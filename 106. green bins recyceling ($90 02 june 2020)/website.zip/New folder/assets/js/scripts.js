jQuery(document).ready(function ($) {

   jQuery('.order_container input[type="date"]').click(function () {
      jQuery(this).css("color", "black")
   })

}); 
