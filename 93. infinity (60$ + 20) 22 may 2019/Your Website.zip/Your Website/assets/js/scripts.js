jQuery(document).ready(function ($) {

   // Owl Carousel
   
   $('.slider').owlCarousel({
      items: 1,
      loop: true,
      autoplay: true,
      autoplayTimeout: 5000,
      dots: true
   });
   
   
   // Other Scripts


});
