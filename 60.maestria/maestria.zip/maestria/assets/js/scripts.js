jQuery(document).ready(function ($) {


   
   // Other Scripts
   //Responsive menu
   jQuery("nav .responsive-menu").click(function () {
      jQuery("nav ul").slideToggle();

      return false;
   });

});
