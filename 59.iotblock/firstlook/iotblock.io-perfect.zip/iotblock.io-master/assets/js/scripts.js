jQuery(window).scroll(function () {

    var distenceFromTop = jQuery(window).scrollTop();

    if (distenceFromTop > 50) {
        jQuery('header').css({
            'background-color': '#fff',
            'border-bottom': '1px solid #bbb',
            'padding': '10px',
        })
    } else {
        jQuery('header').css({
            'background-color': 'transparent',
            'padding': '25px',
            'border-bottom': '1px solid transparent',
        })
    }

});


//MENU
function myFunction(x) {
    x.classList.toggle("change");
    jQuery(".hidden-menu").toggle("slide", { direction: "right" }, 400);
    return false
}

//chatbox
jQuery(".question-heading").click(function () {
    jQuery(".question form").fadeToggle()
    jQuery(".question i.btn-close").fadeToggle()

})
//jQuery(".question i.btn-close").click(function () {
//    jQuery(".question form").fadeOut()
//    jQuery(".question i.btn-close").fadeOut()
//
//})


//FORM


'use strict';

;
(function (document, window, index) {
    var inputs = document.querySelectorAll('.inputfile');
    Array.prototype.forEach.call(inputs, function (input) {
        var label = input.nextElementSibling,
            labelVal = label.innerHTML;

        input.addEventListener('change', function (e) {
            var fileName = '';
            if (this.files && this.files.length > 1)
                fileName = (this.getAttribute('data-multiple-caption') || '').replace('{count}', this.files.length);
            else
                fileName = e.target.value.split('\\').pop();

            if (fileName)
                label.querySelector('span').innerHTML = fileName;
            else
                label.innerHTML = labelVal;
        });

        // Firefox bug fix
        input.addEventListener('focus', function () {
            input.classList.add('has-focus');
        });
        input.addEventListener('blur', function () {
            input.classList.remove('has-focus');
        });
    });
}(document, window, 0));
