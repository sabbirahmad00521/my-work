<?php
require 'mailer/PHPMailerAutoload.php';

$name = $_GET['name'];
$email = $_GET['email'];
$phone = $_GET['phone'];
$stage = $_GET['stage'];
$hear = $_GET['hear'];
$message = $_GET['message'];


$message_to_send = 'From: '.$name.'<br />Email: '.$email.'<br />Phone: '.$phone.'<br />Stage :'.$stage.'<br />Hear about you :'.$hear.'<br />Message: '.$message;


/*$to      = 'sayfarz@gmail.com';
$subject = 'Contact Form Message';
$headers = 'From: '.'contact@financialwealthplanners.com' . "\r\n" .
    'Reply-To: '.$email . "\r\n" .
    'X-Mailer: PHP/' . phpversion(). "\r\n" .
    'Content-type: text/html; charset=iso-8859-1';

mail($to, $subject, $message_to_send, $headers);*/


$mail = new PHPMailer;

//$mail->SMTPDebug = 3;                               // Enable verbose debug output

$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'mail.financialwealthplanners.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'info@financialwealthplanners.com';                 // SMTP username
$mail->Password = 'Blowme2016$';                           // SMTP password
//$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 25;                                    // TCP port to connect to

$mail->setFrom('info@financialwealthplanners.com', 'Mailer');
$mail->addAddress('aftercareadvertising@gmail.com', 'After Care Advertising');     // Add a recipient
$mail->addReplyTo($email, $name);

$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = 'Contact Form Message';
$mail->Body    = $message_to_send;

if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'Message has been sent';
}

?>